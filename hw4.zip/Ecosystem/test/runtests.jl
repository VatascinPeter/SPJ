using Ecosystem
using Test

include("sheep.jl")
include("wolf.jl")
