@testset "Wolf" begin
    wolf = Wolf(1, pf=1.0)
    sheep = Sheep(2)
    world = World([wolf, sheep])
    eat!(wolf, sheep, world)
    @test length(agent_count(world)) == 1
end
